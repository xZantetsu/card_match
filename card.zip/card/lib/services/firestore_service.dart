import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  /// Save or update the best score for the current user.
  Future<void> saveScore(String level, int moves) async {
    final user = _auth.currentUser;
    if (user == null) return;

    final query = await _firestore
        .collection('high_scores')
        .where('level', isEqualTo: level)
        .where('uid', isEqualTo: user.uid)
        .limit(1)
        .get();

    final data = {
      'level': level,
      'moves': moves,
      'timestamp': FieldValue.serverTimestamp(),
      'users': user.displayName ?? user.email ?? 'Anonymous',
      'uid': user.uid,
    };

    if (query.docs.isEmpty) {
      // First time saving a score
      await _firestore.collection('high_scores').add(data);
    } else {
      // Only update if the new score is better (fewer moves)
      final existing = query.docs.first;
      final existingMoves = existing['moves'];
      if (moves < existingMoves) {
        await existing.reference.update(data);
      }
    }
  }

  /// Get top 10 best scores for a level (one per user).
  Future<List<Map<String, dynamic>>> getTopScores(String level) async {
    final snapshot = await _firestore
        .collection('high_scores')
        .where('level', isEqualTo: level)
        .orderBy('moves')
        .limit(10)
        .get();

    return snapshot.docs.map((doc) {
      final data = doc.data();
      data['id'] = doc.id;
      return data;
    }).toList();
  }
}
