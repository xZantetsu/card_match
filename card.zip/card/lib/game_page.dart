import 'package:flutter/material.dart';
import 'dart:math';
import 'package:audioplayers/audioplayers.dart';
import 'package:confetti/confetti.dart';
import 'package:flip_match/services/firestore_service.dart';
import 'package:flip_match/leaderboard_page.dart'; // Make sure this matches your file structure

class GamePage extends StatefulWidget {
  const GamePage({super.key});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> with SingleTickerProviderStateMixin {
  late String level;
  List<int> cards = [];
  List<bool> flipped = [];
  List<int> matchedIndices = [];
  int? firstFlippedIndex;
  bool allowTap = true;
  int moveCount = 0;

  final ConfettiController _confettiController = ConfettiController(duration: const Duration(seconds: 2));
  final AudioPlayer _audioPlayer = AudioPlayer();
  final FirestoreService firestoreService = FirestoreService();

  final List<String> cardImages = [
    'assets/king.png',
    'assets/queen.png',
    'assets/jack.png',
    'assets/spade.png',
    'assets/club.png',
    'assets/heart.png',
    'assets/diamond.png',
    'assets/ace.png',
  ];

  final List<Color> neonColors = [
    Colors.cyanAccent,
    Colors.pinkAccent,
    Colors.greenAccent,
    Colors.amberAccent,
    Colors.blueAccent,
    Colors.deepPurpleAccent,
    Colors.redAccent,
    Colors.tealAccent,
  ];

  late Map<int, Color> cardColors;
  late AnimationController _levelButtonController;
  late Animation<double> _levelButtonAnimation;

  int getPairCount() {
    switch (level) {
      case 'medium':
        return 6;
      case 'hard':
        return 8;
      case 'easy':
      default:
        return 4;
    }
  }

  @override
  void initState() {
    super.initState();
    _levelButtonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _levelButtonAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _levelButtonController, curve: Curves.elasticOut),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    level = ModalRoute.of(context)?.settings.arguments as String? ?? 'easy';
    _initGame();
    _levelButtonController.forward();
  }

  void _initGame() {
    int pairCount = getPairCount();
    List<int> pairIds = List.generate(pairCount, (index) => index);
    cards = [...pairIds, ...pairIds]..shuffle(Random());
    flipped = List.filled(cards.length, false);
    matchedIndices = [];
    firstFlippedIndex = null;
    allowTap = true;
    moveCount = 0;
    cardColors = {
      for (int i = 0; i < cards.length; i++) i: neonColors[Random().nextInt(neonColors.length)],
    };
  }

  Future<void> _playFlipSound() async {
    try {
      await _audioPlayer.play(AssetSource('sounds/flip.mp3'));
    } catch (e) {
      debugPrint("Error playing sound: $e");
    }
  }

  Future<void> _showHighScoresDialog() async {
    final scores = await firestoreService.getTopScores(level);
    if (!mounted) return;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black87,
        title: Text(
          'Top Scores - ${level.toUpperCase()}',
          style: const TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: scores.asMap().entries.map((entry) {
            final i = entry.key + 1;
            final score = entry.value;
            return Text(
              '$i. ${score['moves']} moves',
              style: const TextStyle(color: Colors.white70),
            );
          }).toList(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Colors.cyanAccent)),
          ),
        ],
      ),
    );
  }

  void _onCardTap(int index) async {
    if (!allowTap || flipped[index] || matchedIndices.contains(index)) return;

    await _playFlipSound();

    setState(() {
      flipped[index] = true;
      moveCount++;
    });

    if (firstFlippedIndex == null) {
      firstFlippedIndex = index;
    } else {
      int secondIndex = index;
      int firstIndex = firstFlippedIndex!;

      if (cards[firstIndex] == cards[secondIndex]) {
        matchedIndices.addAll([firstIndex, secondIndex]);
        firstFlippedIndex = null;

        if (matchedIndices.length == cards.length) {
          Future.delayed(const Duration(milliseconds: 500), () async {
            _confettiController.play();
            await firestoreService.saveScore(level, moveCount);
            if (!mounted) return;
            await Future.delayed(const Duration(seconds: 2));
            _showGameCompletedDialog();
          });
        }
      } else {
        allowTap = false;
        Future.delayed(const Duration(milliseconds: 800), () {
          setState(() {
            flipped[firstIndex] = false;
            flipped[secondIndex] = false;
            firstFlippedIndex = null;
            allowTap = true;
          });
        });
      }
    }
  }

  void _showGameCompletedDialog() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(
                colors: [Color(0xFF1e1e2c), Color(0xFF121212)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.7),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'You Won!',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    shadows: [Shadow(color: Colors.purpleAccent, blurRadius: 10)],
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'You finished in $moveCount moves!',
                  style: const TextStyle(fontSize: 18, color: Colors.white70),
                ),
                const SizedBox(height: 24),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  alignment: WrapAlignment.center,
                  children: [
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        setState(() => _initGame());
                      },
                      icon: const Icon(Icons.replay),
                      label: const Text('Replay'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.home),
                      label: const Text('Home'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => LeaderboardPage(level: level),
                          ),
                        );
                      },
                      icon: const Icon(Icons.leaderboard, color: Colors.white),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _confettiController.dispose();
    _levelButtonController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;
    final bool isPortrait = screenHeight > screenWidth;

    final double cardSize = isPortrait ? screenWidth * 0.18 : screenHeight * 0.18;
    final int crossAxisCount = isPortrait ? 4 : 6;

    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/Card.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                      ScaleTransition(
                        scale: _levelButtonAnimation,
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 14),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            gradient: const LinearGradient(
                              colors: [Colors.cyanAccent, Colors.pinkAccent],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.3),
                                blurRadius: 10,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Text(
                            '${level[0].toUpperCase()}${level.substring(1)} Mode - $moveCount moves',
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.leaderboard, color: Colors.white),
                        onPressed: _showHighScoresDialog,
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 100,
                  child: ConfettiWidget(
                    confettiController: _confettiController,
                    blastDirectionality: BlastDirectionality.explosive,
                    emissionFrequency: 0.2,
                    numberOfParticles: 50,
                    gravity: 0.5,
                    shouldLoop: false,
                    colors: const [
                      Colors.pink,
                      Colors.cyan,
                      Colors.yellow,
                      Colors.green,
                      Colors.purple,
                    ],
                  ),
                ),
                Expanded(
                  child: Center(
                    child: SizedBox(
                      width: cardSize * crossAxisCount + 30,
                      height: (cards.length / crossAxisCount).ceil() * (cardSize + 10),
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        padding: EdgeInsets.zero,
                        itemCount: cards.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: crossAxisCount,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                        ),
                        itemBuilder: (context, index) {
                          bool isFlipped = flipped[index] || matchedIndices.contains(index);

                          return GestureDetector(
                            onTap: () => _onCardTap(index),
                            child: TweenAnimationBuilder<double>(
                              tween: Tween<double>(
                                begin: 0,
                                end: isFlipped ? 1 : 0,
                              ),
                              duration: const Duration(milliseconds: 400),
                              curve: Curves.easeInOutBack,
                              builder: (context, value, child) {
                                final isFront = value < 0.5;
                                final displayChild = isFront
                                    ? _buildCardBack(index)
                                    : _buildCardFront(index);

                                return Transform(
                                  transform: Matrix4.rotationY(pi * value),
                                  alignment: Alignment.center,
                                  child: displayChild,
                                );
                              },
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCardFront(int index) {
    final Color neon = cardColors[index] ?? Colors.white;
    final imageIndex = cards[index];

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: const Color(0xFF0A0A0A),
        boxShadow: [
          BoxShadow(
            color: neon.withOpacity(0.8),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Image.asset(
            cardImages[imageIndex % cardImages.length],
            fit: BoxFit.contain,
          ),
        ),
      ),
    );
  }

  Widget _buildCardBack(int index) {
    final Color neon = cardColors[index] ?? Colors.purpleAccent;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: const Color(0xFF0A0A0A),
        boxShadow: [
          BoxShadow(
            color: neon.withOpacity(0.8),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Center(
        child: Icon(Icons.lightbulb, color: neon, size: 36),
      ),
    );
  }
}
