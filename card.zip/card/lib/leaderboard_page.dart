import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flip_match/services/firestore_service.dart';

class LeaderboardPage extends StatelessWidget {
  final String level;
  final FirestoreService firestoreService = FirestoreService();

  LeaderboardPage({super.key, required this.level});

  String formatTimestamp(dynamic timestamp) {
    if (timestamp == null) return '';
    final dt = timestamp.toDate();
    return DateFormat('MMM d, y • hh:mm a').format(dt);
  }

  Icon? getRankIcon(int index) {
    switch (index) {
      case 0:
        return const Icon(Icons.emoji_events, color: Colors.amber);
      case 1:
        return const Icon(Icons.emoji_events, color: Colors.grey);
      case 2:
        return const Icon(Icons.emoji_events, color: Color(0xFFCD7F32)); // bronze
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Leaderboard - ${level.toUpperCase()}'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.cyanAccent,
      ),
      backgroundColor: Colors.black,
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: firestoreService.getTopScores(level),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Colors.cyanAccent),
            );
          } else if (snapshot.hasError) {
            return const Center(
              child: Text('Error loading scores', style: TextStyle(color: Colors.redAccent)),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text('No scores yet', style: TextStyle(color: Colors.white70)),
            );
          }

          final scores = snapshot.data!;
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: scores.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, index) {
              final score = scores[index];
              final rankIcon = getRankIcon(index);

              return Card(
                color: Colors.grey[900],
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.cyanAccent,
                    child: rankIcon ?? Text(
                      '${index + 1}',
                      style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                  ),
                  title: Text(
                    '${score['moves']} moves',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        score['users'] ?? 'Unknown',
                        style: const TextStyle(color: Colors.white70),
                      ),
                      Text(
                        formatTimestamp(score['timestamp']),
                        style: const TextStyle(color: Colors.white54, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
