import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void startGame(BuildContext context, String level) {
    Navigator.pushNamed(context, '/game', arguments: level);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Image
          Container(
            decoration: const BoxDecoration(
              color: Colors.black,
              image: DecorationImage(
                image: AssetImage('assets/Card.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),

          // UI Overlay
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _levelButton(context, 'Easy', Colors.green, () => startGame(context, 'easy')),
                  const SizedBox(height: 16),
                  _levelButton(context, 'Medium', Colors.orange, () => startGame(context, 'medium')),
                  const SizedBox(height: 16),
                  _levelButton(context, 'Hard', Colors.red, () => startGame(context, 'hard')),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _levelButton(BuildContext context, String label, Color color, VoidCallback onTap) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color.withOpacity(0.85),
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        child: Text(label, style: const TextStyle(fontSize: 18, color: Colors.white)),
      ),
    );
  }
}
